//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//
// use APIClient for executing this requests

import UIKit
import Foundation

class ___FILEBASENAMEASIDENTIFIER___Cell: <#cell type#>, ConfigurableCell {
        
    func configure<T>(viewModel: T) {
        <#guard let vm = viewModel as? ViewModelType { return }#>
    }
}
