//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

import UIKit
import Foundation

protocol ___FILEBASENAMEASIDENTIFIER___Protocol {

}

extension ___FILEBASENAMEASIDENTIFIER___Protocol {

}
