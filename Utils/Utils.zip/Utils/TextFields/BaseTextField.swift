//
//  SKBaseTextField.swift
//  SKUtilsSwift
//
//  Created by Mac on 20.07.16.
//  Copyright © 2016 Sergey Kostyan. All rights reserved.
//

import UIKit

class BaseTextField: UITextField {
    
    @IBOutlet var visualisationView : TextFieldAccessoryView? = nil

}
