//
//  ResponseProtocol.swift
//  MyWeather
//
//  Created by Mac on 05.12.16.
//  Copyright © 2016 Sergey Kostyan. All rights reserved.
//


protocol ResponseProtocol {

    init (JSON: AnyObject)

}
